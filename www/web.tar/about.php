<?php include("common.html"); ?> 
<div id="content"> 
    <div id="content-left">
<p> I am currently working in <a href="http://www.greyorangerobotics.com/">Grey Orange Robotics Pvt. Ltd.</a> which is an excellent company in the field of Robotics .</p>
</div>
</div>
</div>

</body>

</html>
