<?php include("common.html"); ?>
<div id="content"> 
    <div id="content-left">
contact me :</br >
<a href="mailto:gauravkumar552@gmail.com">mail </a> </br >
<a href="http://twitter.com/gauravkumar552">tweet </a> </br >
<a href="http://facebook.com/gauravkumar552">facebook </a> </br >
<a href="http://gauravbits.tumblr.com/">tumblr </a> </br >

</div>
</div>
</div>
</body>
</html>
