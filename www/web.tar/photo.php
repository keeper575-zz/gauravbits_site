<?php include("common.html"); ?>    
<div id="content"> 
    <div id="content-left">
    <p> 
<img src="./photos/1.JPG" height=150 width=120/><br />
<img src="./photos/3.JPG" height=150 width=120/>

    </p>
    
    </div>
    <div id="content-right">
<p>
<img src="./photos/2.JPG" height=150 width=120/><br />
<img src="./photos/4.JPG" height=150 width=120/>

</p>
    </div>
    </div>
    
</div>
</body>
</html>

