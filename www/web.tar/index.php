<?php include("common.html"); ?>
    <div id="content"> 
    <div id="content-left">
    <p> 
    Hi all, This is Gaurav Kumar. I just completed final year, M.Sc(tech) Information Systems from BITS pilani.
    </p>
    
    </div>
    <div id="content-right">
    </div>
    </div>
    
</div>
</body>
</html>
